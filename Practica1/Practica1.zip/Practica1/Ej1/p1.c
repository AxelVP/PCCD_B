#include <unistd.h>
#include <signal.h>

int main() {
	
	pause();
	return 0;
}
